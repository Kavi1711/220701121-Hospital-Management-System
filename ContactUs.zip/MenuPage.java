import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;
import java.util.HashMap;
import java.util.Map;

class Patient {
    String name;
    String address;
    String phone;
    String age;
    String illness;
    String dateOfAdmission;
    String gender;
    String doctorNote;

    public Patient(String name, String address, String phone, String age, String illness, String dateOfAdmission, String gender, String doctorNote) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.age = age;
        this.illness = illness;
        this.dateOfAdmission = dateOfAdmission;
        this.gender = gender;
        this.doctorNote = doctorNote;
    }
}

public class MenuPage {
    private JPanel mainbodypanel;
    private Map<Integer, Patient> patientDB = new HashMap<>();
    private int patientIdCounter = 1;
    private JTable patientTable;

    public MenuPage() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        JFrame menupageframe = new JFrame("Menu Page");
        menupageframe.setExtendedState(JFrame.MAXIMIZED_BOTH);
        menupageframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menupageframe.setVisible(true);
        menupageframe.setLayout(null);

        JPanel headerpanel = new JPanel();
        headerpanel.setLayout(null);
        headerpanel.setBounds(10, 10, screenSize.width - 20, 100);
        headerpanel.setBorder(new BevelBorder(BevelBorder.RAISED));

        JLabel heading = new JLabel("SIMPSONS MILITARY HOSPITAL");
        heading.setFont(new Font("Garamond", Font.BOLD, 35));
        heading.setForeground(new Color(0, 255, 226));
        heading.setBounds(screenSize.width - 700, 30, 700, 45);

        headerpanel.add(heading);
        menupageframe.add(headerpanel);

        mainbodypanel = new JPanel();
        mainbodypanel.setLayout(null);
        mainbodypanel.setBounds(5, 110, screenSize.width - 10, screenSize.height - (screenSize.height / 4));
        mainbodypanel.setBackground(Color.WHITE);

        JTabbedPane tabpane = new JTabbedPane();
        tabpane.setBounds(5, 115, screenSize.width - 10, screenSize.height - (screenSize.height / 4));
        menupageframe.add(tabpane);

        JPanel panel1 = new JPanel();
        panel1.setOpaque(true);
        panel1.setLayout(null);

        JPanel outform = new JPanel();
        outform.setLayout(null);
        outform.setBounds(410, 25, 450, 600);
        outform.setBorder(new EtchedBorder(EtchedBorder.RAISED));

        JLabel outlabel = new JLabel("Enter Details of Out Patient");
        outlabel.setBounds(140, 20, 300, 40);
        JTextField outname = new JTextField("Enter Name");
        outname.setBounds(80, 70, 300, 40);
        outname.setForeground(Color.GRAY);
        outname.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outname.getText().equals("Enter Name")) {
                    outname.setText("");
                    outname.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outname.getText().isEmpty()) {
                    outname.setForeground(Color.GRAY);
                    outname.setText("Enter Name");
                }
            }
        });

        JTextField outaddress = new JTextField("Enter Address");
        outaddress.setBounds(80, 120, 300, 40);
        outaddress.setForeground(Color.GRAY);
        outaddress.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outaddress.getText().equals("Enter Address")) {
                    outaddress.setText("");
                    outaddress.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outaddress.getText().isEmpty()) {
                    outaddress.setForeground(Color.GRAY);
                    outaddress.setText("Enter Address");
                }
            }
        });

        JTextField outnumber = new JTextField("Enter Ph no");
        outnumber.setBounds(80, 170, 300, 40);
        outnumber.setForeground(Color.GRAY);
        outnumber.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outnumber.getText().equals("Enter Ph no")) {
                    outnumber.setText("");
                    outnumber.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outnumber.getText().isEmpty()) {
                    outnumber.setForeground(Color.GRAY);
                    outnumber.setText("Enter Ph no");
                }
            }
        });

        JTextField outage = new JTextField("Enter Age");
        outage.setBounds(80, 220, 300, 40);
        outage.setForeground(Color.GRAY);
        outage.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outage.getText().equals("Enter Age")) {
                    outage.setText("");
                    outage.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outage.getText().isEmpty()) {
                    outage.setForeground(Color.GRAY);
                    outage.setText("Enter Age");
                }
            }
        });

        JTextField outillness = new JTextField("Enter Illness");
        outillness.setBounds(80, 270, 300, 40);
        outillness.setForeground(Color.GRAY);
        outillness.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outillness.getText().equals("Enter Illness")) {
                    outillness.setText("");
                    outillness.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outillness.getText().isEmpty()) {
                    outillness.setForeground(Color.GRAY);
                    outillness.setText("Enter Illness");
                }
            }
        });

        JTextField outdateofadmission = new JTextField("Date of Admission (YYYY-MM-DD)");
        outdateofadmission.setBounds(80, 320, 300, 40);
        outdateofadmission.setForeground(Color.GRAY);
        outdateofadmission.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outdateofadmission.getText().equals("Date of Admission (YYYY-MM-DD)")) {
                    outdateofadmission.setText("");
                    outdateofadmission.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outdateofadmission.getText().isEmpty()) {
                    outdateofadmission.setForeground(Color.GRAY);
                    outdateofadmission.setText("Date of Admission (YYYY-MM-DD)");
                }
            }
        });

        JTextArea outnote = new JTextArea("Doctor's Note");
        outnote.setBounds(80, 370, 300, 70);
        outnote.setForeground(Color.GRAY);
        outnote.setLineWrap(true);
        outnote.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (outnote.getText().equals("Doctor's Note")) {
                    outnote.setText("");
                    outnote.setForeground(Color.BLACK);
                }
            }

            public void focusLost(FocusEvent e) {
                if (outnote.getText().isEmpty()) {
                    outnote.setForeground(Color.GRAY);
                    outnote.setText("Doctor's Note");
                }
            }
        });

        // Gender Selection
        String[] genderOptions = {"Male", "Female"};
        JComboBox<String> genderComboBox = new JComboBox<>(genderOptions);
        genderComboBox.setBounds(80, 450, 300, 40);

        JButton outbutton = new JButton("Submit");
        outbutton.setBounds(100, 520, 250, 40);

        outform.add(outlabel);
        outform.add(outname);
        outform.add(outaddress);
        outform.add(outnumber);
        outform.add(outage);
        outform.add(outillness);
        outform.add(outdateofadmission);
        outform.add(outnote);
        outform.add(genderComboBox);
        outform.add(outbutton);

        panel1.add(outform);

        outbutton.addActionListener(ae -> {
            Patient patient = new Patient(outname.getText(), outaddress.getText(), outnumber.getText(),
                    outage.getText(), outillness.getText(), outdateofadmission.getText(), (String) genderComboBox.getSelectedItem(), outnote.getText());
            patientDB.put(patientIdCounter, patient);
            updatePatientTable();
            patientIdCounter++;
            JOptionPane.showMessageDialog(null, "Successfully entered details");
        });

        JPanel patientdbpanel = new JPanel();
        patientdbpanel.setLayout(null);

        JButton editpatient = new JButton("Edit Records");
        editpatient.setBounds(550, 15, 150, 40);
        editpatient.addActionListener(ae -> {
            String input = JOptionPane.showInputDialog(null, "Enter Patient ID:");
            if (input != null && !input.isEmpty()) {
                int patientId = Integer.parseInt(input);
                if (patientDB.containsKey(patientId)) {
                    editPatientDetails(patientId);
                } else {
                    JOptionPane.showMessageDialog(null, "Patient ID not found.");
                }
            }
        });
        patientdbpanel.add(editpatient);

        JButton generateReportButton = new JButton("Generate Report");
        generateReportButton.setBounds(1050, 15, 150, 40);
        generateReportButton.addActionListener(ae -> generateReport());
        patientdbpanel.add(generateReportButton);

        String[] columnNames = {"Patient ID", "Name", "Address", "Phone", "Age", "Illness", "Date of Admission", "Gender", "Doctor's Note"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        patientTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(patientTable);
        scrollPane.setBounds(50, 60, 1800, 600);
        patientdbpanel.add(scrollPane);

        tabpane.add("Out Patient Registration Form", panel1);
        tabpane.add("Patient Database", patientdbpanel);
    }

    private void updatePatientTable() {
        DefaultTableModel tableModel = (DefaultTableModel) patientTable.getModel();
        tableModel.setRowCount(0);
        for (Map.Entry<Integer, Patient> entry : patientDB.entrySet()) {
            int patientId = entry.getKey();
            Patient patient = entry.getValue();
            Object[] rowData = {patientId, patient.name, patient.address, patient.phone, patient.age,
                    patient.illness, patient.dateOfAdmission, patient.gender, patient.doctorNote};
            tableModel.addRow(rowData);
        }
    }

    private void editPatientDetails(int patientId) {
        Patient patient = patientDB.get(patientId);
        JTextField nameField = new JTextField(patient.name);
        JTextField addressField = new JTextField(patient.address);
        JTextField phoneField = new JTextField(patient.phone);
        JTextField ageField = new JTextField(patient.age);
        JTextField illnessField = new JTextField(patient.illness);
        JTextField dateField = new JTextField(patient.dateOfAdmission);
        JComboBox<String> genderComboBox = new JComboBox<>(new String[]{"Male", "Female"});
        genderComboBox.setSelectedItem(patient.gender);
        JTextArea noteArea = new JTextArea(patient.doctorNote);

        Object[] message = {
                "Name:", nameField,
                "Address:", addressField,
                "Phone:", phoneField,
                "Age:", ageField,
                "Illness:", illnessField,
                "Date of Admission:", dateField,
                "Gender:", genderComboBox,
                "Doctor's Note:", noteArea
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Edit Patient Details", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            patient.name = nameField.getText();
            patient.address = addressField.getText();
            patient.phone = phoneField.getText();
            patient.age = ageField.getText();
            patient.illness = illnessField.getText();
            patient.dateOfAdmission = dateField.getText();
            patient.gender = (String) genderComboBox.getSelectedItem();
            patient.doctorNote = noteArea.getText();
            updatePatientTable();
        }
    }

    private void generateReport() {
        // For simplicity, we can print the report in the console.
        // This method can be expanded to generate a detailed report in a file or other formats.
        System.out.println("Patient Report:");
        for (Map.Entry<Integer, Patient> entry : patientDB.entrySet()) {
            int patientId = entry.getKey();
            Patient patient = entry.getValue();
            System.out.println("Patient ID: " + patientId);
            System.out.println("Name: " + patient.name);
            System.out.println("Address: " + patient.address);
            System.out.println("Phone: " + patient.phone);
            System.out.println("Age: " + patient.age);
            System.out.println("Illness: " + patient.illness);
            System.out.println("Date of Admission: " + patient.dateOfAdmission);
            System.out.println("Gender: " + patient.gender);
            System.out.println("Doctor's Note: " + patient.doctorNote);
            System.out.println("-----------------------");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPage());
    }
}
